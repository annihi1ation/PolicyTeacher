# -*- coding: utf-8 -*-
"""BERT-based emotion detection for the teaching agent (local-first)"""

import os
import logging
from typing import Optional, Dict

import torch
from transformers import pipeline

from models import EmotionState


class BERTEmotionDetector:
    """BERT-based emotion detection using Hugging Face transformers"""

    def __init__(self, model_name: Optional[str] = None):
        """
        Initialize the BERT-based emotion detector.

        Args:
            model_name: Local directory or HF repo id for emotion detection.
                        Priority:
                          1) the given `model_name` argument
                          2) env var EMOTION_MODEL_DIR
                          3) default local dir (/root/.cache/hf/...),
                             then fallback to HF repo id
        """
        # 默认优先使用你已下载好的本地目录；可被传参或环境变量覆盖
        local_default = "/root/.cache/huggingface/agents/emotion-english-distilroberta-base"
        repo_fallback = "j-hartmann/emotion-english-distilroberta-base"

        chosen = model_name or os.getenv("EMOTION_MODEL_DIR") or local_default
        self._model_source = chosen  # for logging / debug

        try:
            # 使用 text-classification 更通用；tokenizer 与 model 指向同一路径
            self.classifier = pipeline(
                task="text-classification",
                model=chosen,
                tokenizer=chosen,
                device=0 if torch.cuda.is_available() else -1,
            )
            logging.info(f"[Emotion] Loaded model from: {chosen}")
        except Exception as e:
            logging.error(f"[Emotion] Failed to load '{chosen}': {e}")

            # 若本地模型不可用，尝试远程常用二分类情感模型作为回退
            try:
                self.classifier = pipeline(
                    task="sentiment-analysis",
                    model="distilbert-base-uncased-finetuned-sst-2-english",
                    device=-1,
                )
                logging.info("[Emotion] Using fallback sentiment model (SST-2).")
            except Exception as e2:
                # 最终兜底：规则法
                self.classifier = None
                logging.warning(
                    f"[Emotion] Fallback pipeline failed ({e2}); using rule-based detector."
                )

    def detect_emotion(self, text: str) -> EmotionState:
        """
        Detect emotion from user input.

        Args:
            text: User input text.
        Returns:
            Detected EmotionState.
        """
        if not self.classifier:
            return self._rule_based_detection(text)

        try:
            # 对于 text-classification，top_k=None 会返回所有标签（若支持），否则返回 top-1
            results = self.classifier(text, top_k=None)

            # pipeline 可能返回 [{'label': 'xxx', 'score': 0.9}] 或 [[...]] 的嵌套结构
            if isinstance(results, list) and results and isinstance(results[0], list):
                results = results[0]

            emotion_mapping = {
                "joy": EmotionState.HAPPY,
                "happiness": EmotionState.HAPPY,
                "positive": EmotionState.HAPPY,
                "excitement": EmotionState.EXCITED,
                "surprise": EmotionState.EXCITED,
                "sadness": EmotionState.SAD,
                "negative": EmotionState.SAD,
                "fear": EmotionState.FRUSTRATED,
                "anger": EmotionState.FRUSTRATED,
                "disgust": EmotionState.FRUSTRATED,
                "neutral": EmotionState.NEUTRAL,
                "love": EmotionState.HAPPY,
            }

            for result in results:
                label = str(result.get("label", "")).lower()
                for key, emotion_state in emotion_mapping.items():
                    if key in label:
                        return emotion_state

            return EmotionState.NEUTRAL

        except Exception as e:
            logging.error(f"[Emotion] Error in emotion detection: {e}")
            return self._rule_based_detection(text)

    def _rule_based_detection(self, text: str) -> EmotionState:
        """Very simple rule-based fallback when ML models are unavailable."""
        text_lower = text.lower()

        emotion_keywords = {
            EmotionState.EXCITED: ["wow", "awesome", "cool", "amazing", "yay", "fun", "great", "love", "!"],
            EmotionState.HAPPY: ["happy", "good", "nice", "like", "yes", "okay", "thanks"],
            EmotionState.FRUSTRATED: ["hard", "difficult", "can't", "dont know", "don't know", "confused", "no", "wrong"],
            EmotionState.TIRED: ["tired", "sleepy", "boring", "enough", "stop", "later"],
            EmotionState.SAD: ["sad", "miss", "lonely", "cry", "hurt"],
        }

        scores = {}
        for emotion, keywords in emotion_keywords.items():
            score = sum(1 for kw in keywords if kw in text_lower)
            if score > 0:
                scores[emotion] = score

        if scores:
            return max(scores.items(), key=lambda x: x[1])[0]
        return EmotionState.NEUTRAL

    def get_emotion_confidence(self, text: str) -> Dict[str, float]:
        """
        Get confidence scores for each emotion.

        Args:
            text: User input text.
        Returns:
            Dict of {emotion_name: confidence}.
        """
        if not self.classifier:
            detected = self._rule_based_detection(text)
            return {emotion.value: (1.0 if emotion == detected else 0.0) for emotion in EmotionState}

        try:
            results = self.classifier(text, top_k=None)

            # 同样处理可能的嵌套结构
            if isinstance(results, list) and results and isinstance(results[0], list):
                results = results[0]

            confidence = {emotion.value: 0.0 for emotion in EmotionState}

            emotion_mapping = {
                "joy": EmotionState.HAPPY,
                "happiness": EmotionState.HAPPY,
                "positive": EmotionState.HAPPY,
                "excitement": EmotionState.EXCITED,
                "surprise": EmotionState.EXCITED,
                "sadness": EmotionState.SAD,
                "negative": EmotionState.SAD,
                "fear": EmotionState.FRUSTRATED,
                "anger": EmotionState.FRUSTRATED,
                "disgust": EmotionState.FRUSTRATED,
                "neutral": EmotionState.NEUTRAL,
                "love": EmotionState.HAPPY,
            }

            for result in results:
                label = str(result.get("label", "")).lower()
                score = float(result.get("score", 0.0))
                for key, emo in emotion_mapping.items():
                    if key in label:
                        # 取最大分
                        confidence[emo.value] = max(confidence[emo.value], score)
                        break

            return confidence

        except Exception as e:
            logging.error(f"[Emotion] Error getting emotion confidence: {e}")
            detected = self._rule_based_detection(text)
            return {emotion.value: (1.0 if emotion == detected else 0.0) for emotion in EmotionState}


# Backward compatibility alias
EmotionDetector = BERTEmotionDetector
