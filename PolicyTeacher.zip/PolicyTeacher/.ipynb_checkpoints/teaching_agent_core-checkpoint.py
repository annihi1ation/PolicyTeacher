# teaching_agent_core.py
# -*- coding: utf-8 -*-
"""Core teaching agent (Qwen/DashScope OpenAI-compatible) — no ReAct, no external tools."""

import os
from typing import List, Dict, Optional, Tuple
from datetime import datetime

from langchain_openai import ChatOpenAI

from models import (
    TeachingContext, StudentProfile, EmotionState,
    LanguageLevel, TeachingPolicy, ChatMessage
)
from prompts import (
    teaching_prompt_template, teaching_character,
    teaching_user_profile, teaching_rules, level_instructions, teaching_prompt
)
from utils import (
    WordManager, SessionStorage, get_encouragement
)
from emotion_detector import EmotionDetector
from language_level_agent import LanguageLevelAgent
from policy_generator_agent import PolicyGeneratorAgent


# --------------------- Helpers ---------------------

def _truncate_history(messages: List[ChatMessage], max_pairs: int = 3) -> str:
    """Take last N pairs (user+assistant) and format concise visible chat history for the prompt."""
    # 只取最后 max_pairs*2 条（user/assistant交替），并转为简短可读格式
    recent = []
    cnt = 0
    for m in reversed(messages):
        recent.append(m)
        if m.role == "user":
            cnt += 1
            if cnt >= max_pairs:
                break
    recent = list(reversed(recent))
    lines = []
    for m in recent:
        role = "Child" if m.role == "user" else "Sparky"
        # 控制每条历史不太长
        text = m.content.strip().replace("\n", " ")
        if len(text) > 160:
            text = text[:160] + "..."
        lines.append(f"{role}: {text}")
    return "\n".join(lines)


def _compose_system_prompt(
    emotion: EmotionState,
    trend: EmotionState,
    needs_intervention: bool,
    word_category: str,
    level: LanguageLevel,
    policy_text: str,
) -> str:
    """Compose a single robust system prompt (no ReAct), injecting all rules & dynamic context."""
    # 动态规则：等级适配提示 + 情绪 + 中文词密度 + 提问配额
    level_tips = level_instructions.get(level.value, level_instructions["L1"]).strip()

    # 给模型明确指令：不要用工具、不要解释思路、直接生成1-3句
    guard = (
        "Do NOT use tools. Do NOT output chain-of-thought. "
        "Reply ONLY as Sparky in 1-3 short sentences. "
        "Mandarin use: 1-2 words/mini-phrases that fit the child's action/feeling; prefer whole words (e.g., 跑跑/喝水/好吃/星星) over single characters. "
        "Respect closing/low-energy rules; avoid repeated A-or-B choices; vary interjections and their positions."
    )

    dyn = f"""
Dynamic context:
- Child emotion: {emotion.value} (trend: {trend.value})
- Needs gentle support now: {needs_intervention}
- Today's word category: {word_category}
- Language level: {level.value}

Level adaptation (auto-apply):
{level_tips}

Additional policy:
{policy_text}

Hard guardrails:
{guard}
""".strip()

    # 汇总成一个稳定的 system prompt
    sys_prompt = "\n\n".join([
        "ROLE / CHARACTER",
        teaching_character.strip(),
        "USER PROFILE",
        teaching_user_profile.strip(),
        "CORE RULES",
        teaching_rules.strip(),
        dyn
    ])
    return sys_prompt


def _format_user_turn(visible_history: str, user_text: str) -> str:
    """Build the single user message shown to the model."""
    return (
        "Previous fun times (short):\n"
        + (visible_history if visible_history else "(none)") +
        "\n\nNew input from child:\n"
        + user_text.strip()
        + "\n\nReminder: Keep it playful and short (1-3 sentences). Weave 1 Mandarin word/mini-phrase that fits. "
          "If last turn had a question, prefer no question now. If closing/low-energy intent, close softly without new invites."
    )


# --------------------- Core ---------------------

class TeachingAgentCore:
    """Chat-only agent (no tools), stable output for Qwen (DashScope OpenAI-compatible)."""

    def __init__(
        self,
        session_id: str,
        api_key: str,
        base_url: Optional[str] = None,         # e.g. https://dashscope.aliyuncs.com/compatible-mode/v1
        model_name: str = "qwen-plus",
    ):
        self.session_id = session_id
        self.storage = SessionStorage()

        # Load or create student profile
        self.student_profile = self.storage.load_profile(session_id)
        if not self.student_profile:
            self.student_profile = StudentProfile(session_id=session_id)

        # Components
        self.word_manager = WordManager()
        self.emotion_detector = EmotionDetector()
        self.level_evaluator = LanguageLevelAgent(api_key, base_url, model_name)
        self.policy_generator = PolicyGeneratorAgent(api_key, base_url, model_name)

        # Teaching context
        self.context = TeachingContext(
            student_profile=self.student_profile,
            current_word_category=self.word_manager.get_random_category()
        )

        # LLM (OpenAI-compatible -> DashScope)
        self.llm = ChatOpenAI(
            api_key=api_key,
            base_url=base_url,
            model=model_name,
            temperature=0.3,     # 更稳
            timeout=30,
            max_retries=2,
        )

        # 生成初始 policy 并构建 system prompt
        self._refresh_system_prompt()

        # 计数会话
        self.student_profile.session_count += 1

        # 健康检查（可选）
        try:
            _ = self.llm.invoke("ping")
        except Exception as e:
            print(f"[HealthCheck] LLM call failed (you can ignore if rate-limited): {e}")

    # ---------- Prompt building ----------

    def _refresh_system_prompt(self):
        """Rebuild system prompt when emotion/level/policy changes."""
        try:
            policy_text = self.policy_generator.generate_policy(
                self.context.current_emotion,
                self.student_profile.language_level,
                self.context.emotion_trend
            )
        except Exception as e:
            print(f"[Warn] Policy generator failed: {e}")
            policy_text = ""

        self.system_prompt = _compose_system_prompt(
            self.context.current_emotion,
            self.context.emotion_trend,
            self.context.needs_intervention,
            self.context.current_word_category,
            self.student_profile.language_level,
            policy_text,
        )

    # ---------- Core chat ----------

    def process_input(self, user_input: str) -> str:
        """Process user input and generate response (no ReAct)."""

        # 1) Emotion detect
        emotion = self.emotion_detector.detect_emotion(user_input)
        self.context.current_emotion = emotion

        # 2) Add message
        self.context.add_message("user", user_input, emotion)

        # 3) Update language level every 5 messages
        if len(self.context.session_messages) % 5 == 0:
            try:
                new_level, confidence = self.level_evaluator.evaluate_level(
                    self.context.session_messages
                )
                if confidence > 0.7 and new_level != self.student_profile.language_level:
                    self.student_profile.language_level = new_level
                    print(f"[System] Language level updated to {new_level.value}")
                    # 等级变化后刷新 system prompt
                    self._refresh_system_prompt()
            except Exception as e:
                print(f"[Warn] Level evaluation failed: {e}")

        # 4) 可能需要刷新 policy（例如需要干预 or 每 10 条）
        if self.context.needs_intervention or len(self.context.session_messages) % 10 == 0:
            self._refresh_system_prompt()

        # 5) Compose visible history and user message
        visible_history = _truncate_history(self.context.session_messages, max_pairs=3)
        user_msg = _format_user_turn(visible_history, user_input)

        # 6) Call LLM (no tools)
        try:
            messages = [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": user_msg},
            ]
            result = self.llm.invoke(messages)
            output = result.content.strip()

            # 记录
            self.context.add_message("assistant", output)

            # 7) Track Chinese words for mastery
            for word in self._extract_chinese_words(output):
                self.student_profile.add_learned_word(word, 5)

            return output

        except Exception as e:
            msg = repr(e)
            print(f"[Error] LLM invoke failed: {msg}")
            text = str(e)
            if "invalid_api_key" in text or "Incorrect API key" in text:
                error_msg = "Auth error: invalid DashScope API key. Check DASHSCOPE_API_KEY or --api-key."
            elif "unsupported_country" in text or "unsupported_country_region_territory" in text:
                error_msg = "Region error: current machine egress IP not supported."
            elif "model" in text and "not found" in text:
                error_msg = "Model error: model not found/unavailable. Try 'qwen-plus' or check console."
            else:
                brief = text[-200:] if text else "unknown error"
                error_msg = f"Oops! Something went wrong. ({brief})"
            self.context.add_message("assistant", error_msg)
            return error_msg

    # ---------- Utils ----------

    def _extract_chinese_words(self, text: str) -> List[str]:
        """Extract continuous CJK spans as 'words' (simple)."""
        words: List[str] = []
        cur = ""
        for ch in text:
            if '\u4e00' <= ch <= '\u9fff':
                cur += ch
            else:
                if cur:
                    words.append(cur)
                    cur = ""
        if cur:
            words.append(cur)
        return words

    # ---------- Summary / Save / End ----------

    def get_session_summary(self) -> Dict[str, any]:
        duration = self.context.get_session_duration()
        return {
            "session_id": self.session_id,
            "duration_minutes": duration,
            "messages_count": len(self.context.session_messages),
            "current_level": self.student_profile.language_level.value,
            "current_emotion": self.context.current_emotion.value,
            "emotion_trend": self.context.emotion_trend.value,
            "words_learned": len([w for w, m in self.student_profile.learned_words.items() if m > 0]),
            "total_sessions": self.student_profile.session_count
        }

    def save_session(self):
        # 累计时长
        self.student_profile.total_interaction_time += self.context.get_session_duration()
        # 保存档案与日志
        self.storage.save_profile(self.student_profile)
        self.storage.save_session_log(self.session_id, self.context.session_messages)

    def end_session(self) -> str:
        self.save_session()
        if self.context.current_emotion in [EmotionState.HAPPY, EmotionState.EXCITED]:
            farewell = "That was so much fun! See you next time, buddy! 🌟 再见 (zàijiàn)!"
        elif self.context.current_emotion in [EmotionState.TIRED, EmotionState.SAD]:
            farewell = "Rest well, my friend! Tomorrow will be even better! 💤 晚安 (wǎn'ān)!"
        else:
            farewell = "Great job today! Can't wait to play again! 👋 再见 (zàijiàn)!"
        return farewell


class SimpleTeachingAgent:
    """Simplified interface for CLI usage"""

    def __init__(
        self,
        session_id: str,
        api_key: str,
        base_url: Optional[str] = None,
        model_name: str = "qwen-plus",
    ):
        self.core = TeachingAgentCore(session_id, api_key, base_url, model_name)

    def chat(self, message: str) -> str:
        return self.core.process_input(message)

    def get_summary(self) -> Dict[str, any]:
        return self.core.get_session_summary()

    def end(self) -> str:
        return self.core.end_session()
